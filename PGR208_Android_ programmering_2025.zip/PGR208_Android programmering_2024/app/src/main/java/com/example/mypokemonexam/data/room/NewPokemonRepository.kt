package com.example.mypokemonexam.data.room

import android.content.Context
import android.util.Log
import androidx.room.Room
import java.sql.SQLException

object NewPokemonRepository {
    private lateinit var _newPokemonDatabase: NewPokemonDatabase
    private val _newPokemonDao by lazy { _newPokemonDatabase.newPokemonDao() }

    fun initializeDatabase(context: Context){
        _newPokemonDatabase = Room.databaseBuilder(
            context = context,
            klass = NewPokemonDatabase::class.java,
            name = "newpokemon-database"
        ).build()
    }

    suspend fun getNewPokemons() : List<NewPokemon>{
        try {
            return _newPokemonDao.getNewPokemons()
        }catch (e: SQLException){
            Log.d("Databasefeil", e.toString())
            return emptyList()
        }catch (e: Exception){
            Log.d("Annenfeil", e.toString())
            return emptyList()
        }
    }

    suspend fun insertNewPokemon(newPokemon: NewPokemon) : Long {
        return try {
            _newPokemonDao.insertNewPokemon(newPokemon)
        }catch (e: SQLException){
            -1L
        }
    }

}