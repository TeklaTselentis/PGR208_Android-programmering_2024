package com.example.mypokemonexam.screens.pokemonList

import android.media.Image
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.example.mypokemonexam.R
import com.example.mypokemonexam.components.PokemonItem
import com.example.rickandmortyapp.screens.PokemonListViewModel

@Composable
fun PokemonListScreen(
    viewModel: PokemonListViewModel = viewModel(),
    navController: NavHostController
) {
    val pokemons by viewModel.pokemons.observeAsState(emptyList())
    var searchQuery by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFEF5350))
            .padding(16.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.pokemonlogooriginal),
            contentDescription = "Pokemon Logo",
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .padding(bottom = 16.dp)
        )


        TextField(
            value = searchQuery,
            onValueChange = {
                searchQuery = it
                viewModel.filterPokemons(it)
            },
            placeholder = { Text("Search by id or name") },
            leadingIcon = {
                Icon(Icons.Filled.Search, contentDescription = "Search Icon")
            },
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFFFF59D))
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            items(pokemons) { pokemon ->
                PokemonItem(
                    pokemon = pokemon,
                    onFavoriteClick = { /* Add toggle favorite logic */ }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}
