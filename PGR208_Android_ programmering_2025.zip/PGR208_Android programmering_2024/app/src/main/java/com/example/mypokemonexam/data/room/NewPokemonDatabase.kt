package com.example.mypokemonexam.data.room

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.mypokemonexam.data.room.NewPokemon
import com.example.mypokemonexam.data.room.NewPokemonDao

@Database(
    entities = [NewPokemon::class],
    version = 1,
    exportSchema = false
)

abstract class NewPokemonDatabase : RoomDatabase() {
    abstract fun newPokemonDao() : NewPokemonDao
}