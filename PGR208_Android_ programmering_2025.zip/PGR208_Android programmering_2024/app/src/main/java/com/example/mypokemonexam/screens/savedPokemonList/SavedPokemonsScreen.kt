package com.example.mypokemonexam.screens.savedPokemonList

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.mypokemonexam.R
import com.example.mypokemonexam.components.NewPokemonItem
import com.example.mypokemonexam.navigation.AppNavigation
import com.example.mypokemonexam.screens.createPokemon.CreatePokemonViewModel

@Composable
fun SavedPokemonsScreen(
    navController: NavController,
    createPokemonViewModel: CreatePokemonViewModel

){
    LaunchedEffect(Unit) {
        createPokemonViewModel.setNewPokemons()
    }

    val newPokemons = createPokemonViewModel.newPokemons.collectAsState()

    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFEF5350))
            .padding(16.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.pokemonlogooriginal),
            contentDescription = "Pokemon Logo",
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .padding(bottom = 16.dp)
        )
    }
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 56.dp)
    ){
        LazyColumn (
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 100.dp)
                .padding(bottom = 1.dp)
        ) {
            items(newPokemons.value){ newPokemon ->
                NewPokemonItem(newPokemon = newPokemon)
            }
        }

    }

        Button(
            onClick = { navController.navigate("Create")},
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 680.dp)
            ) {
            Text(text = "Create new Pokemon")
        }
}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun SavedPokemonPreview(){
    AppNavigation()
}