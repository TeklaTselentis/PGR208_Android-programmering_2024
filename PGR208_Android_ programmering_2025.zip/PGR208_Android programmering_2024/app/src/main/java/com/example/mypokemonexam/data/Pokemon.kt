package com.example.mypokemonexam.data

import com.google.gson.annotations.SerializedName

data class Pokemon(
    val id: Int,
    val name: String,
    @SerializedName("sprites")
    val sprites: Sprites,
    @SerializedName("types")
    val types: List<TypeSlot>,
    @SerializedName("stats")
    val stats: List<Stat>
)

data class Sprites(
    @SerializedName("front_default")
    val frontDefault: String?
)

data class TypeSlot(
    @SerializedName("type")
    val type: PokemonType
)

data class PokemonType(
    val name: String
)

data class Stat(
    @SerializedName("stat")
    val stat: StatDetail,
    @SerializedName("base_stat")
    val baseStat: Int
)

data class StatDetail(
    val name: String
)
