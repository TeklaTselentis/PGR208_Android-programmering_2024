package com.example.mypokemonexam.screens.createPokemon

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mypokemonexam.data.room.NewPokemon
import com.example.mypokemonexam.data.room.NewPokemonRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CreatePokemonViewModel : ViewModel() {
    private val _newPokemons = MutableStateFlow<List<NewPokemon>>(emptyList())
    val newPokemons = _newPokemons.asStateFlow()

    fun setNewPokemons(){
        viewModelScope.launch(Dispatchers.IO) {
            _newPokemons.value = NewPokemonRepository.getNewPokemons()
        }
    }

    fun insertNewPokemon(newPokemon: NewPokemon){
        viewModelScope.launch(Dispatchers.IO) {
            val newNewPokemonId = NewPokemonRepository.insertNewPokemon(newPokemon)
            if(newNewPokemonId != -1L){
                setNewPokemons()
                val newNewPokemon = newPokemon.copy(id = newNewPokemonId.toInt())
                _newPokemons.value += newNewPokemon
            }
        }
    }

}