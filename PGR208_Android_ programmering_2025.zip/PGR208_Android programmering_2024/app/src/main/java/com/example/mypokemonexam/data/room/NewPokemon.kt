package com.example.mypokemonexam.data.room

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class NewPokemon(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val type: String
)