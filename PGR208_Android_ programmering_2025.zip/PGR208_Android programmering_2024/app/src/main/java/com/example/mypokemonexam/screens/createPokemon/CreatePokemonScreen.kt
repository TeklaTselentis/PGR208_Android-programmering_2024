package com.example.mypokemonexam.screens.createPokemon

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.mypokemonexam.R
import com.example.mypokemonexam.data.room.NewPokemon
import com.example.mypokemonexam.navigation.AppNavigation

@Composable
fun CreatePokemonScreen(
    navController: NavController,
    createPokemonViewModel: CreatePokemonViewModel,
){

    var name by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("") }

    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFEF5350))
            .padding(16.dp)
    ) {
        Image(
            painter = painterResource(id = R.drawable.pokemonlogooriginal),
            contentDescription = "Pokemon Logo",
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .padding(bottom = 16.dp)
        )
    }

    Column (
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 90.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally

    ) {
        TextField(
            value = name,
            onValueChange = { name = it },
            label = { Text(text = "Name") }
        )

        TextField(
            value = type,
            onValueChange = { type = it },
            label = { Text(text = "Type") }
        )

        Button(
            onClick = {
                val newNewPokemon = NewPokemon(name = name, type = type)
                createPokemonViewModel.insertNewPokemon(newNewPokemon)
            }
        ) {
            Text(text = "Save pokemon")
        }

        Button(
            onClick = { navController.navigate("Saved")}
        ) {
            Text(text = "View New Pokemons")
        }

    }

}

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun CreatePokemonPreview(){
    AppNavigation()
}