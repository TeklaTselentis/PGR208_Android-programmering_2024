package com.example.mypokemonexam.data

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object PokemonRepository {
    private val _okHttpClient = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
        .build()

    private val _retrofit = Retrofit.Builder()
        .client(_okHttpClient)
        .baseUrl("https://pokeapi.co/api/v2/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    private val _pokemonService = _retrofit.create(PokemonService::class.java)

    suspend fun getPokemonListById(startId: Int = 1, count: Int = 100): List<Pokemon> {
        return try {
            (startId until startId + count).mapNotNull { id ->
                val response = _pokemonService.getPokemon(id)  // Dette matcher @GET("pokemon/{id}")
                if (response.isSuccessful) {
                    response.body()
                } else {
                    null
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
