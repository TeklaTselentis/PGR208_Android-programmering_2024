package com.example.mypokemonexam.data

data class PokemonList(
    val results: List<Pokemon>
)
