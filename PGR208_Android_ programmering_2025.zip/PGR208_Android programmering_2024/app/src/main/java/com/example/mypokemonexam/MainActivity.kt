package com.example.mypokemonexam

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.example.mypokemonexam.data.room.NewPokemonRepository
import com.example.mypokemonexam.navigation.AppNavigation
import com.example.mypokemonexam.screens.createPokemon.CreatePokemonViewModel
import com.example.mypokemonexam.ui.theme.MyPokemonExamTheme

class MainActivity : ComponentActivity() {
    private val _createPokemonViewModel : CreatePokemonViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        NewPokemonRepository.initializeDatabase(applicationContext)

        enableEdgeToEdge()
        setContent {
            MyPokemonExamTheme {
                val navController = rememberNavController()
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    Column(modifier = Modifier.padding(innerPadding)){
                        AppNavigation()
                    }
                }
            }
        }
    }
}