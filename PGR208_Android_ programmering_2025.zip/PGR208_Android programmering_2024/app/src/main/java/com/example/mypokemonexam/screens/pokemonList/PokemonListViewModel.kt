package com.example.rickandmortyapp.screens

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mypokemonexam.data.Pokemon
import com.example.mypokemonexam.data.PokemonRepository
import kotlinx.coroutines.launch

class PokemonListViewModel : ViewModel() {

    private val _pokemons = MutableLiveData<List<Pokemon>>()
    val pokemons: LiveData<List<Pokemon>> get() = _pokemons

    private val allPokemons = mutableListOf<Pokemon>()

    init {
        fetchPokemons()
    }

    private fun fetchPokemons() {
        viewModelScope.launch {
            val fetchedPokemons = PokemonRepository.getPokemonListById(1, 100)
            allPokemons.clear()
            allPokemons.addAll(fetchedPokemons)
            _pokemons.postValue(fetchedPokemons)
        }
    }

    fun filterPokemons(query: String) {
        _pokemons.value = if (query.isBlank()) {
            allPokemons
        } else {
            allPokemons.filter { it.name.contains(query, ignoreCase = true) || it.id.toString() == query }
        }
    }
}
