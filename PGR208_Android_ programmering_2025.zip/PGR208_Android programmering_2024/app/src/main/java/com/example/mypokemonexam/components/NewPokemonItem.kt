package com.example.mypokemonexam.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.mypokemonexam.R
import com.example.mypokemonexam.data.room.NewPokemon

@Composable
fun NewPokemonItem (newPokemon: NewPokemon){
    Row (
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .background(Color(0xFFFFCC00))
            .padding(16.dp)

    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
        ){
            Image(
                painter = painterResource(id = R.drawable.charmeleon),
                contentDescription = "Charmeleon",
                modifier = Modifier.size(64.dp)
            )
        }


        Column(modifier = Modifier.weight(1f)) {
            Text(text = newPokemon.name, fontSize = 18.sp)
            Text(text = newPokemon.type, fontSize = 14.sp, color = Color.Gray)
        }
    }
}