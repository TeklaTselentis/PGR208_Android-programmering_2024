package com.example.mypokemonexam.data.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface NewPokemonDao {
    @Query("SELECT * FROM NewPokemon ORDER BY id DESC")
    suspend fun getNewPokemons() : List<NewPokemon>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNewPokemon(newPokemon: NewPokemon) : Long
}