package com.example.mypokemonexam.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.mypokemonexam.screens.createPokemon.CreatePokemonScreen
import com.example.mypokemonexam.screens.pokemonList.PokemonListScreen
import com.example.mypokemonexam.screens.savedPokemonList.SavedPokemonsScreen
import kotlinx.serialization.Serializable

@Serializable
object List

@Serializable
object Saved

@Serializable
object Create



@Composable
fun AppNavigation(){
    val navController = rememberNavController()

    var selectedItemIndex by rememberSaveable{
        mutableIntStateOf(0)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize(),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFFFFCC00)) {

                NavigationBarItem(
                    selected = selectedItemIndex == 0,
                    onClick = {
                        selectedItemIndex = 0
                        navController.navigate("Create")
                    },
                    icon = {
                        if (selectedItemIndex == 0){
                            Icon(imageVector = Icons.Filled.Add, contentDescription = null)
                        }else{
                            Icon(imageVector = Icons.Filled.Add, contentDescription = null)
                        }
                    },
                    label = {
                        Text(text = "Create")
                    }
                )


                NavigationBarItem(
                    selected = selectedItemIndex == 1,
                    onClick = {
                        selectedItemIndex = 1
                        navController.navigate("Saved")
                    },
                    icon = {
                        if (selectedItemIndex == 1){
                            Icon(imageVector = Icons.Filled.Favorite, contentDescription = null)
                        }else{
                            Icon(imageVector = Icons.Filled.Favorite, contentDescription = null)
                        }
                    },
                    label = {
                        Text(text = "Saved")
                    }
                )

                NavigationBarItem(
                    selected = selectedItemIndex == 2,
                    onClick = {
                        selectedItemIndex = 2
                        navController.navigate("List")
                    },
                    icon = {
                        if (selectedItemIndex == 2){
                            Icon(imageVector = Icons.Filled.List, contentDescription = null)
                        }else{
                            Icon(imageVector = Icons.Filled.List, contentDescription = null)
                        }
                    },
                    label = {
                        Text(text = "List")
                    }
                )
            }
        }
    ){ innerPadding ->
        Column(modifier = Modifier.padding(innerPadding)) {
            NavHost(
                navController = navController,
                startDestination = "Create"
            ){
                composable("Create") {
                    CreatePokemonScreen(navController = navController, createPokemonViewModel = viewModel())
                }
                composable("Saved"){
                    SavedPokemonsScreen(navController = navController, createPokemonViewModel = viewModel())
                }
                composable("List"){
                    PokemonListScreen(navController = navController)
                }
            }
        }
    }
}


@Preview (showBackground = true, showSystemUi = true)
@Composable
fun AppNavigationPreview(){
    AppNavigation()
}