package com.example.mypokemonexam.components

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.mypokemonexam.data.Pokemon


@Composable
fun PokemonItem(pokemon: Pokemon, onFavoriteClick: () -> Unit){
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .background(Color(0xFFFFCC00))
            .padding(16.dp)
    ) {
        val imageUrl = pokemon.sprites?.frontDefault ?: ""

        AsyncImage(
            model = pokemon.sprites?.frontDefault,
            contentDescription = pokemon.name,
            modifier = Modifier.size(64.dp)
        )

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(text = "#${pokemon.id}", style = MaterialTheme.typography.bodyMedium)
            Text(text = pokemon.name, style = MaterialTheme.typography.titleMedium)
            Text(text = "Type: ${pokemon.types?.joinToString { it.type.name }}", style = MaterialTheme.typography.bodyMedium)

            Spacer(modifier = Modifier.height(8.dp))

            pokemon.stats?.forEach { stat ->
                Text(
                    text = "${stat.stat.name.capitalize()}: ${stat.baseStat}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}



